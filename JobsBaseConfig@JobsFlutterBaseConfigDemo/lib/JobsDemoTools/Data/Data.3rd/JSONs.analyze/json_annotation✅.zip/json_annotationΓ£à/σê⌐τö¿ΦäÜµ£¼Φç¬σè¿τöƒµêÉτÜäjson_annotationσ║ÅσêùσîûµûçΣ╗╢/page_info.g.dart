// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../json_annotation模型文件/page_info.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PageInfo _$PageInfoFromJson(Map<String, dynamic> json) => PageInfo(
      pn: json['pn'] as String,
      rn: json['rn'] as String,
    );

Map<String, dynamic> _$PageInfoToJson(PageInfo instance) => <String, dynamic>{
      'pn': instance.pn,
      'rn': instance.rn,
    };
