import 'package:json_annotation/json_annotation.dart';
import 'video_item.dart';
import 'page_info.dart';

part '../利用脚本自动生成的json_annotation序列化文件/response.g.dart';

@JsonSerializable(explicitToJson: true)
class ResponseData {
  final List<VideoItem> list;
  final PageInfo page;

  ResponseData({
    required this.list,
    required this.page,
  });

  factory ResponseData.fromJson(Map<String, dynamic> json) => _$ResponseDataFromJson(json);
  Map<String, dynamic> toJson() => _$ResponseDataToJson(this);
}
