import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'json_annotation模型文件/response.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: VideoListScreen(),
    );
  }
}

class VideoListScreen extends StatefulWidget {
  const VideoListScreen({super.key});

  @override
  _VideoListScreenState createState() => _VideoListScreenState();
}

class _VideoListScreenState extends State<VideoListScreen> {
  ResponseData? _responseData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadVideos();
  }

  Future<void> _loadVideos() async {
    try {
      final jsonString = await rootBundle.loadString('assets/Jsons/data.json');
      final jsonResponse = json.decode(jsonString);
      final responseData = ResponseData.fromJson(jsonResponse);
      setState(() {
        _responseData = responseData;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Videos')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _responseData?.list.length ?? 0,
              itemBuilder: (context, index) {
                final video = _responseData!.list[index];
                return ListTile(
                  leading: Image.network(video.head),
                  title: Text(video.nickName),
                  subtitle: Text(video.title),
                );
              },
            ),
    );
  }
}
