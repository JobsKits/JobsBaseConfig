import 'package:json_annotation/json_annotation.dart';

part '../利用脚本自动生成的json_annotation序列化文件/page_info.g.dart';

@JsonSerializable()
class PageInfo {
  final String pn;
  final String rn;

  PageInfo({
    required this.pn,
    required this.rn,
  });

  factory PageInfo.fromJson(Map<String, dynamic> json) => _$PageInfoFromJson(json);
  Map<String, dynamic> toJson() => _$PageInfoToJson(this);
}
