import 'package:json_annotation/json_annotation.dart';

part '../利用脚本自动生成的json_annotation序列化文件/video_item.g.dart';

@JsonSerializable()
class VideoItem {
  @JsonKey(name: 'nick_name')
  final String nickName;
  final String head;
  @JsonKey(name: 'thread_id')
  final String threadId;
  @JsonKey(name: 'first_post_id')
  final String firstPostId;
  @JsonKey(name: 'create_time')
  final String createTime;
  @JsonKey(name: 'play_count')
  final String playCount;
  @JsonKey(name: 'post_num')
  final String postNum;
  @JsonKey(name: 'agree_num')
  final String agreeNum;
  @JsonKey(name: 'share_num')
  final String shareNum;
  @JsonKey(name: 'has_agree')
  final String hasAgree;
  @JsonKey(name: 'freq_num')
  final String freqNum;
  @JsonKey(name: 'forum_id')
  final String forumId;
  final String title;
  final String source;
  final String weight;
  final String extra;
  @JsonKey(name: 'abtest_tag')
  final String abtestTag;
  @JsonKey(name: 'thumbnail_width')
  final String thumbnailWidth;
  @JsonKey(name: 'thumbnail_height')
  final String thumbnailHeight;
  @JsonKey(name: 'video_md5')
  final String videoMd5;
  @JsonKey(name: 'video_url')
  final String videoUrl;
  @JsonKey(name: 'video_duration')
  final String videoDuration;
  @JsonKey(name: 'video_width')
  final String videoWidth;
  @JsonKey(name: 'video_height')
  final String videoHeight;
  @JsonKey(name: 'video_type')
  final String videoType;
  @JsonKey(name: 'thumbnail_url')
  final String thumbnailUrl;
  @JsonKey(name: 'video_format')
  final String videoFormat;
  @JsonKey(name: 'thumbnail_picid')
  final String thumbnailPicid;
  @JsonKey(name: 'video_from')
  final String videoFrom;
  @JsonKey(name: 'video_log_id')
  final String videoLogId;
  final String auditing;
  @JsonKey(name: 'origin_video_url')
  final String originVideoUrl;
  @JsonKey(name: 'video_length')
  final String videoLength;
  @JsonKey(name: 'video_size')
  final String videoSize;

  VideoItem({
    required this.nickName,
    required this.head,
    required this.threadId,
    required this.firstPostId,
    required this.createTime,
    required this.playCount,
    required this.postNum,
    required this.agreeNum,
    required this.shareNum,
    required this.hasAgree,
    required this.freqNum,
    required this.forumId,
    required this.title,
    required this.source,
    required this.weight,
    required this.extra,
    required this.abtestTag,
    required this.thumbnailWidth,
    required this.thumbnailHeight,
    required this.videoMd5,
    required this.videoUrl,
    required this.videoDuration,
    required this.videoWidth,
    required this.videoHeight,
    required this.videoType,
    required this.thumbnailUrl,
    required this.videoFormat,
    required this.thumbnailPicid,
    required this.videoFrom,
    required this.videoLogId,
    required this.auditing,
    required this.originVideoUrl,
    required this.videoLength,
    required this.videoSize,
  });

  factory VideoItem.fromJson(Map<String, dynamic> json) => _$VideoItemFromJson(json);
  Map<String, dynamic> toJson() => _$VideoItemToJson(this);
}
